/*******************************************************************************
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright (c) 2014,2015 by Peter Pilgrim, Milton Keynes, P.E.A.T LTD
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the GNU GPL v3.0
 * which accompanies this distribution, and is available at:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 *
 * Developers:
 * Peter Pilgrim -- design, development and implementation
 *               -- Blog: http://www.xenonique.co.uk/blog/
 *               -- Twitter: @peter_pilgrim
 *
 * Contributors:
 *
 *******************************************************************************/

package uk.co.xenonique.basic.mvc;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import java.time.LocalDate;
import java.util.*;


/**
 * The type CreditCardChecker
 *
 * @author Peter Pilgrim
 */
public class CreditCardChecker {
//    @ApplicationScoped
//    public class CreditCardTicketTracker() {
//
//    // Rely on CDI product factory to inject the correct type
//    @Inject PaymentIssuer issuer;
//
//    public void processTickets( List<Ticket> ticketBatch ) {
//        final LocalDate dt = LocalDate.now().plusDays(2);
//        ticketBatch.stream()
//                .filter(
//                        t -> t.isAvailable()  &&
//                                t -> t.paymentType == PaymentType.CreditCard &&
//                                        dt.isAfter( t.getConcertDate() ))
//                .map( t -> p.getAllocationId() )
//                .forEach( allocationId -> issuer.allocate(allocationId));
//    }
//

}


